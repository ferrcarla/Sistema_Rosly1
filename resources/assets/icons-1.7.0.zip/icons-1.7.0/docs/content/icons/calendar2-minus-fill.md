---
title: Calendar2 minus fill
layout: icon
categories:
  - Date and time
tags:
  - date
  - time
  - month
---
