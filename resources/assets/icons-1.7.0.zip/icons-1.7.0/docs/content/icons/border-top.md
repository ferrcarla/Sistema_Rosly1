---
title: Border top
categories:
  - UI and keyboard
tags:
  - borders
---
